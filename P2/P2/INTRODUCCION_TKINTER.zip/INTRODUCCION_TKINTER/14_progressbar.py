from tkinter import *

ventana=Tk()

ventana.title("Progress Bar")
ventana.geometry("500x500")