from tkinter import *

ventana=Tk()

ventana.title("Menu")
ventana.geometry("500x500")




ventana.mainloop()