from tkinter import *

ventana=Tk()

ventana.title("Alertas")
ventana.geometry("500x500")