from tkinter import *

ventana=Tk()

ventana.title("Imagenes Pillow")
ventana.geometry("500x500")